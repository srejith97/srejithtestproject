package ftrservelet;

import java.io.IOException;
import java.sql.Array;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ftrbean.Ftrbean;
import ftrdao.Ftrdao;

/**
 * Servlet implementation class Serveletftr
 */
@WebServlet("/Serveletftr")
public class Serveletftr extends HttpServlet {
private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Serveletftr() {
        super();
        // TODO Auto-generated constructor stub
    }

/**
* @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
*/
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
response.getWriter().append("Served at: ").append(request.getContextPath());
}

/**
* @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
*/
protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
// TODO Auto-generated method stub
doGet(request, response);




String action=request.getParameter("action");

/*OTP Generation*/


if(action.equals("insert1"))
{
String generated=request.getParameter("generated");
String fname=request.getParameter("fname");
String lname=request.getParameter("lname");
String email=request.getParameter("email");
String phone=request.getParameter("phone");

HttpSession ses=request.getSession();

ses.setAttribute("fname", fname);
ses.setAttribute("lname", lname);
ses.setAttribute("email", email);
ses.setAttribute("gotp", generated);
ses.setAttribute("phone", phone);

Ftrbean ob=new Ftrbean();
Ftrdao obj=new Ftrdao();
ob.setFname(fname);
ob.setLname(lname);
ob.setEmail(email);
ob.setPhno(phone);
ob.setOtp(generated);
String ok=obj.sendMail(ob);
if(ok.equals("SUCCESS"))
{
	request.getRequestDispatcher("Verification.jsp").forward(request, response);	
}
}
if(action.equals("otpcheck"))
{
	
String generated=request.getParameter("generated");
String fname=request.getParameter("fname");
String lname=request.getParameter("lname");
String email=request.getParameter("email");
String phone=request.getParameter("phone");
String userotp=request.getParameter("uotp");

Ftrbean ob=new Ftrbean();
Ftrdao obj=new Ftrdao();
ob.setFname(fname);
ob.setLname(lname);
ob.setEmail(email);
ob.setPhno(phone);
if(userotp.equals(generated))
{

String ok=obj.userReg(ob);

if(ok.equals("success"))
{
request.getRequestDispatcher("main.jsp").forward(request, response);
}
}

}

if(action.equals("insert2"))
{
	
String address=request.getParameter("address");
String state=request.getParameter("state");
String qualification=request.getParameter("department");
String branch=request.getParameter("Branch");
String fdate=request.getParameter("fdate");
String tdate=request.getParameter("tdate");
String arrier=request.getParameter("chk");
String ano=request.getParameter("ano");
String amark=request.getParameter("amark");
String college=request.getParameter("college");
String twelth=request.getParameter("twelth");
String tenth=request.getParameter("tenth");
String cv=request.getParameter("cv");
String img=request.getParameter("img");
String email=request.getParameter("email");
Ftrbean bean=new Ftrbean();

bean.setAddress(address);
bean.setState(state);
bean.setQualification(qualification);
bean.setBranch(branch);
bean.setFdate(fdate);
bean.setTdate(tdate);
bean.setArrier(arrier);
bean.setAno(ano);
bean.setAmark(amark);
bean.setCollege(college);
bean.setTwelth(twelth);
bean.setTenth(tenth);
bean.setCv(cv);
bean.setImg(img);
bean.setEmail(email);

Ftrdao obj=new Ftrdao();
String ok=obj.updateuser(bean);
if(ok.equals("success"))
{
	ArrayList<Ftrbean> list=obj.companymatch();
	HttpSession ses=request.getSession();
	ses.setAttribute("mlist", list);
	ses.setAttribute("eid",email);
	request.getRequestDispatcher("NewFile.jsp").forward(request, response);
	
}

}

if(action.equals("adminlogin"))
{
String uname=request.getParameter("uname");
String password=request.getParameter("password");
if(uname.equals("admin") && password.equals("123"))
{
	request.getRequestDispatcher("AdminHome.jsp").forward(request, response);
	
}
else
{
	request.getRequestDispatcher("Adminlogin.jsp").forward(request, response);
}
}

if(action.equals("cinsertion"))
{
String cname=request.getParameter("cname");
String cemail=request.getParameter("cemail");
String cphone=request.getParameter("cphone");
String clocation=request.getParameter("location");
String jdescription=request.getParameter("jdescription");
//String cskill=request.getParameter("skill");
String camark=request.getParameter("camark");
String cdepartment=request.getParameter("cdepartment");
String cbranch=request.getParameter("cbranch");
String yop=request.getParameter("yop");
String ctc=request.getParameter("ctc");
String skill="";
String lang[]=request.getParameterValues("lang");
for(int i=0;i<lang.length;i++){
	skill+=lang[i]+" ";
}


Ftrbean ob=new Ftrbean();

ob.setCname(cname);
ob.setCemail(cemail);
ob.setCphone(cphone);
ob.setClocation(clocation);
ob.setJdescription(jdescription);
ob.setCskill(skill);
ob.setCamark(camark);
ob.setCdepartment(cdepartment);
ob.setCbranch(cbranch);
ob.setYop(yop);
ob.setCtc(ctc);

Ftrdao dobj=new Ftrdao();
String ok=dobj.CompReg(ob);

if(ok.equals("success"))
{
	request.getRequestDispatcher("AdminHome.jsp").forward(request, response);
}

}


if(action.equals("companyview"))
{
	Ftrdao ob2=new Ftrdao();
	Ftrbean bean=new Ftrbean();
	ArrayList<Ftrbean> list=ob2.getcinfo();
	HttpSession ses=request.getSession();
	ses.setAttribute("clist", list);
	request.getRequestDispatcher("Cview.jsp").forward(request, response);	

}
if(action.equals("candidateview"))
{
	Ftrdao ob2=new Ftrdao();
	Ftrbean bean=new Ftrbean();
	ArrayList<Ftrbean> list=ob2.getcandidateinfo();
	HttpSession ses=request.getSession();
	ses.setAttribute("clist", list);
	request.getRequestDispatcher("Candidateview.jsp").forward(request, response);	

}
if(action.equals("update"))
{
	 String id=request.getParameter("id");
	 
	 Ftrbean obj=new Ftrbean();
	 obj.setCid(id);
     Ftrdao obj1=new Ftrdao();
	 ArrayList <Ftrbean> list= obj1.ugetinfo(obj);
	 HttpSession ses=request.getSession();
	 ses.setAttribute("clist", list);
	 request.getRequestDispatcher("Cupdate.jsp").forward(request, response);
	 
}
if(action.equals("updateinsert")){
	 String cname=request.getParameter("cname");
		String cemail=request.getParameter("cemail");
		String cphone=request.getParameter("cphone");
		String location=request.getParameter("location");
		String jdescription=request.getParameter("jdescription");
		String skill=request.getParameter("skill");
		String camark=request.getParameter("camark");
		String cdepartment=request.getParameter("cdepartment");
		String cbranch=request.getParameter("cbranch");
		String yop=request.getParameter("yop");
		String ctc=request.getParameter("ctc");
		String cid=request.getParameter("id");
		 
		Ftrbean ob= new Ftrbean();
		Ftrdao obj1=new Ftrdao();
		ob.setCname(cname);
		ob.setCemail(cemail);
		ob.setCphone(cphone);
		ob.setClocation(location);
		ob.setJdescription(jdescription);
		ob.setCskill(skill);
		ob.setCamark(camark);
		ob.setCdepartment(cdepartment);
		ob.setCbranch(cbranch);
		ob.setYop(yop);
		ob.setCtc(ctc);
		ob.setCid(cid);
		  
		  String msg=obj1.update(ob);
		  if(msg.equals("ok")){
			  request.getRequestDispatcher("AdminHome.jsp").forward(request, response);
		  }
	 
}
if(action.equals("delete")){
	 String cid=request.getParameter("cid");
	 Ftrbean regiobj= new Ftrbean();
		Ftrdao obj1=new Ftrdao();
	  regiobj.setCid(cid);
	  String msg=obj1.delete(regiobj);
	  if(msg.equals("ok")){
		  request.getRequestDispatcher("AdminHome.jsp").forward(request, response);
	  }
	 
}

if(action.equals("companyselection"))
{
String cid=request.getParameter("company");
String email=request.getParameter("email");
Ftrbean ob=new Ftrbean();
ob.setId(cid);
ob.setEmail(email);
Ftrdao obj=new Ftrdao();
String ok=obj.cidins(ob);
if (ok.equals("ok"))
{
	  request.getRequestDispatcher("Welcome.jsp").forward(request, response);
	
}
}



}

}


	
	
	
