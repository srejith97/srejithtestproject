package ftrbean;

public class Ftrbean {
	
	public String fname;
	public String lname;
	public String email;
	public String phno;
	public String otp;

public String address;
public String state;
public String qualification;
public String branch;
public String fdate;
public String tdate;
public String arrier;
public String ano;
public String amark;
public String college;
public String twelth;
public String tenth;
public String cv;
public String img;
public String id;

public String getId() {
	return id;
}
public void setId(String id) {
	this.id = id;
}
public String cname;
public String cemail;
public String cphone;
public String clocation;
public String jdescription;
public String cid;
public String getCid() {
	return cid;
}
public void setCid(String cid) {
	this.cid = cid;
}
public String cskill;
public String getCskill() {
	return cskill;
}
public void setCskill(String cskill) {
	this.cskill = cskill;
}
public String camark;
public String cdepartment;
public String cbranch;
public String yop;
public String ctc;

	public String getCname() {
	return cname;
}
public void setCname(String cname) {
	this.cname = cname;
}
public String getCemail() {
	return cemail;
}
public void setCemail(String cemail) {
	this.cemail = cemail;
}
public String getCphone() {
	return cphone;
}
public void setCphone(String cphone) {
	this.cphone = cphone;
}
public String getClocation() {
	return clocation;
}
public void setClocation(String clocation) {
	this.clocation = clocation;
}
public String getJdescription() {
	return jdescription;
}
public void setJdescription(String jdescription) {
	this.jdescription = jdescription;
}

public String getCamark() {
	return camark;
}
public void setCamark(String camark) {
	this.camark = camark;
}
public String getCdepartment() {
	return cdepartment;
}
public void setCdepartment(String cdepartment) {
	this.cdepartment = cdepartment;
}
public String getCbranch() {
	return cbranch;
}
public void setCbranch(String cbranch) {
	this.cbranch = cbranch;
}
public String getYop() {
	return yop;
}
public void setYop(String yop) {
	this.yop = yop;
}
public String getCtc() {
	return ctc;
}
public void setCtc(String ctc) {
	this.ctc = ctc;
}
	public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public String getState() {
	return state;
}
public void setState(String state) {
	this.state = state;
}
public String getQualification() {
	return qualification;
}
public void setQualification(String qualification) {
	this.qualification = qualification;
}
public String getBranch() {
	return branch;
}
public void setBranch(String branch) {
	this.branch = branch;
}
public String getFdate() {
	return fdate;
}
public void setFdate(String fdate) {
	this.fdate = fdate;
}
public String getTdate() {
	return tdate;
}
public void setTdate(String tdate) {
	this.tdate = tdate;
}
public String getArrier() {
	return arrier;
}
public void setArrier(String arrier) {
	this.arrier = arrier;
}
public String getAno() {
	return ano;
}
public void setAno(String ano) {
	this.ano = ano;
}
public String getAmark() {
	return amark;
}
public void setAmark(String amark) {
	this.amark = amark;
}
public String getCollege() {
	return college;
}
public void setCollege(String college) {
	this.college = college;
}
public String getTwelth() {
	return twelth;
}
public void setTwelth(String twelth) {
	this.twelth = twelth;
}
public String getTenth() {
	return tenth;
}
public void setTenth(String tenth) {
	this.tenth = tenth;
}
public String getCv() {
	return cv;
}
public void setCv(String cv) {
	this.cv = cv;
}
public String getImg() {
	return img;
}
public void setImg(String img) {
	this.img = img;
}
	public String getOtp() {
		return otp;
	}
	public String setOtp(String otp) {
		return this.otp = otp;
	}
	public String getFname() {
		return fname;
	}
	public void setFname(String fname) {
		this.fname = fname;
	}
	public String getLname() {
		return lname;
	}
	public void setLname(String lname) {
		this.lname = lname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhno() {
		return phno;
	}
	public void setPhno(String phno) {
		this.phno = phno;
	}
	

	
}
