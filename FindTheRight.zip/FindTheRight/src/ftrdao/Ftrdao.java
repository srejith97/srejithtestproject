package ftrdao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Random;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import ftrbean.Ftrbean;
import ftrdao.DatabaseConnector;


public class Ftrdao {
	
DatabaseConnector dobj=new DatabaseConnector();
	
	Connection con=dobj.Dbconnect();
	PreparedStatement ps=null;
	Statement st=null;
	ResultSet rs=null;
/**user Registration */
    
	public String userReg(Ftrbean obj)
	{
		try{
		String add="insert into candidate_register (flname,lname,email,phone)values('"+obj.getFname()+"','"+obj.getLname()+"','"+obj.getEmail()+"','"+obj.getPhno()+"')";
		
		ps=con.prepareStatement(add);
	
		
		int i=ps.executeUpdate();
		if(i!=0)
		{
			return "success";
		}
		else
		{
			return "failure";
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return "";
	}
	/*Sending otp to Candidate*/
	public String sendMail(Ftrbean beanobj)
	{
		

	String id=beanobj.getEmail();

	String msg=("Hi,"+beanobj.getFname()+" your Record was Successfully added, your otp is "+beanobj.getOtp());

	final String username = "athirashaji250@gmail.com";
	final String password = "Thankyou@301";

	Properties props = new Properties();
	props.put("mail.smtp.auth", "true");
	props.put("mail.smtp.starttls.enable", "true");
	props.put("mail.smtp.host", "smtp.gmail.com");
	props.put("mail.smtp.port", "587");

	Session session = Session.getInstance(props,
	 new javax.mail.Authenticator() {
	protected PasswordAuthentication getPasswordAuthentication() {
	return new PasswordAuthentication(username, password);
	}
	 });

	try {

	Message message = new MimeMessage(session);
	message.setFrom(new InternetAddress("athirashaji250@gmail.com"));
	message.setRecipients(Message.RecipientType.TO,
	InternetAddress.parse(id));
	message.setSubject("Admin MedRec");
	message.setText(msg);
	System.out.println(msg);
	Transport.send(message);


	System.out.println("Done");

	} catch (MessagingException e) {
	throw new RuntimeException(e);
	}





	return "SUCCESS";


	}
	
	

	public String updateuser(Ftrbean bean)
	{
	
		try{
			String add="update candidate_register set address='"+bean.getAddress()+"',state='"+bean.getState()+"',qualification='"+bean.getQualification()+"',branch='"+bean.getBranch()+"',pfrom='"+bean.getFdate()+"',pto='"+bean.getTdate()+"',arriers='"+bean.getArrier()+"',ano='"+bean.getAno()+"',apercent='"+bean.getAmark()+"',college='"+bean.getCollege()+"',twelth='"+bean.getTwelth()+"',tenth='"+bean.getTenth()+"',cvfile='"+bean.getCv()+"',image='"+bean.getImg()+"' where email='"+bean.getEmail()+"' ";
			
			
			ps=con.prepareStatement(add);
			int i=ps.executeUpdate();
			
			if(i!=0)
			{
				return "success";
			}
			else
			{
				return "failure";
			}
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
		return "";
			
		
	}
	
	

	/*Insert Company Details*/
	public String CompReg(Ftrbean cbean)
	{
		try{
		String add="insert into company_list (companyname,email,contactno,location,jobdesc,skillset,aggregate,qualification,branch,yop,ctc)values('"+cbean.getCname()+"','"+cbean.getCemail()+"','"+cbean.getCphone()+"','"+cbean.getClocation()+"','"+cbean.getJdescription()+"','"+cbean.getCskill()+"','"+cbean.getCamark()+"','"+cbean.getCdepartment()+"','"+cbean.getCbranch()+"','"+cbean.getYop()+"','"+cbean.getCtc()+"')";
		
		ps=con.prepareStatement(add);
	
		
		int i=ps.executeUpdate();
		if(i!=0)
		{
			return "success";
		}
		else
		{
			return "failure";
		}
		}
		catch(Exception e)
		{
			System.out.println(e);
		}
		return "";
	}

	public ArrayList<Ftrbean> getcinfo() {
		ArrayList <Ftrbean> list=new ArrayList <Ftrbean>();
		try
		{
			String view="select * from company_list";
			ps=con.prepareStatement(view);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Ftrbean ob=new Ftrbean();
				ob.setCid(rs.getString("id"));
				ob.setCname(rs.getString("companyname"));
				ob.setCemail(rs.getString("email"));
				ob.setCphone(rs.getString("contactno"));
				ob.setClocation(rs.getString("location"));
				ob.setJdescription(rs.getString("jobdesc"));
				ob.setCskill(rs.getString("skillset"));
				ob.setCamark(rs.getString("aggregate"));
				ob.setCdepartment(rs.getString("qualification"));
				ob.setCbranch(rs.getString("branch"));
				ob.setYop(rs.getString("yop"));
				ob.setCtc(rs.getString("ctc"));
				list.add(ob);
			}
			
		}
		catch(Exception e)
			{
				System.out.println(e);
			}		
		return list;
		
		
	}
	
	
	public ArrayList<Ftrbean> getcandidateinfo() {
		ArrayList <Ftrbean> list=new ArrayList <Ftrbean>();
		try
		{
			String view="select * from candidate_register";
			ps=con.prepareStatement(view);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Ftrbean ob=new Ftrbean();
				ob.setFname(rs.getString("flname"));
				ob.setLname(rs.getString("lname"));
				ob.setEmail(rs.getString("email"));
				ob.setAddress(rs.getString("address"));
				ob.setState(rs.getString("state"));
				ob.setPhno(rs.getString("phone"));
				ob.setQualification(rs.getString("qualification"));
				ob.setBranch(rs.getString("branch"));
				ob.setFdate(rs.getString("pfrom"));
				ob.setTdate(rs.getString("pto"));
				ob.setArrier(rs.getString("arriers"));
				ob.setAno(rs.getString("ano"));
				ob.setAmark(rs.getString("apercent"));
				ob.setCollege(rs.getString("college"));
				ob.setTwelth(rs.getString("twelth"));
				ob.setTenth(rs.getString("tenth"));
				ob.setCv(rs.getString("cvfile"));
				ob.setImg(rs.getString("image"));
				
				
				list.add(ob);
			}
			
		}
		catch(Exception e)
			{
				System.out.println(e);
			}		
		return list;
		
		
	}
	
	
	public ArrayList<Ftrbean> ugetinfo(Ftrbean ob){
		ArrayList <Ftrbean> list=new ArrayList <Ftrbean>();
		try{
			String viewed="select * from company_list where id='"+ob.getCid()+"'";
			ps=con.prepareStatement(viewed);
			rs=ps.executeQuery();
			while(rs.next()){
			
				
				ob.setCid(rs.getString("id"));
				ob.setCname(rs.getString("companyname"));
				ob.setCemail(rs.getString("email"));
				ob.setCphone(rs.getString("contactno"));
				ob.setClocation(rs.getString("location"));
				ob.setJdescription(rs.getString("jobdesc"));
				ob.setCskill(rs.getString("skillset"));
				ob.setCamark(rs.getString("aggregate"));
				ob.setCdepartment(rs.getString("qualification"));
				ob.setCbranch(rs.getString("branch"));
				ob.setYop(rs.getString("yop"));
				ob.setCtc(rs.getString("ctc"));
				
				list.add(ob);		
				
			}
		}
		catch(Exception e){
			System.out.println(e);
			
			
			
			
			
		}
		return list;
	
	}
	
	public String update(Ftrbean obj)
	{
		try{
		String add="update company_list set companyname=?,email=?,contactno=?,location=?,jobdesc=?,skillset=?,aggregate=?,qualification=?,branch=?,yop=?,ctc=? where id='"+obj.getId()+"'" ;
		con=dobj.Dbconnect();
		ps=con.prepareStatement(add);
		ps.setString(1,obj.getCname());
		ps.setString(2, obj.getCemail());
		ps.setString(3, obj.getCphone());
		ps.setString(4, obj.getClocation());
		ps.setString(5, obj.getJdescription());
		ps.setString(6, obj.getCskill());
		ps.setString(7, obj.getCamark());
		ps.setString(8, obj.getCdepartment());
		ps.setString(9, obj.getCbranch());
		ps.setString(10, obj.getYop());
		ps.setString(11, obj.getCtc());
		
		int i=ps.executeUpdate();
		if(i!=0)
		{

		return "ok";

		}

		}

		catch(Exception e)
		{
		System.out.println(e);
		}
		
		
		return "ok";
	}
	
	public String delete(Ftrbean obj)
	{
		try{
		String add="delete from company_list where id='"+obj.getCid()+"'" ;
		con=dobj.Dbconnect();
		ps=con.prepareStatement(add);
		int i=ps.executeUpdate();
		if(i!=0)
		{

		return "ok";

		}

		}

		catch(Exception e)
		{
		System.out.println(e);
		}
		
		
		return "ok";
	}
	
	
	public ArrayList<Ftrbean> companymatch() {
		ArrayList <Ftrbean> list=new ArrayList <Ftrbean>();
		try
		{
			String view="SELECT companyname,jobdesc,ctc,contactno,location FROM company_list INNER JOIN candidate_register ON candidate_register.qualification = company_list.qualification  && candidate_register.apercent=company_list.aggregate";
			ps=con.prepareStatement(view);
			rs=ps.executeQuery();
			while(rs.next())
			{
				Ftrbean ob=new Ftrbean();
			
				ob.setCname(rs.getString("companyname"));
			
				ob.setCphone(rs.getString("contactno"));
				ob.setClocation(rs.getString("location"));
				ob.setJdescription(rs.getString("jobdesc"));
			
				ob.setCtc(rs.getString("ctc"));
				list.add(ob);
			}
			
		}
		catch(Exception e)
			{
				System.out.println(e);
			}		
		return list;
		
		
	}
	
	
	

	public String cidins(Ftrbean obj)
	{
		try{
		String add="update candidate_register set cid='"+obj.getCid()+"'  where id='"+obj.getEmail()+"'" ;
		con=dobj.Dbconnect();
		ps=con.prepareStatement(add);
			
		int i=ps.executeUpdate();
		if(i!=0)
		{

		return "ok";

		}

		}

		catch(Exception e)
		{
		System.out.println(e);
		}
		
		
		return "ok";
	}
	

}
